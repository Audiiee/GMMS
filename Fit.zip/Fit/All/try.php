<?php
phpinfo();

echo "PHP Version: " . phpversion();

?>
